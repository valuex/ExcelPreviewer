﻿namespace XPDFViewer
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            sumatraPDFControl1 = new SumatraPDF.SumatraPDFControl();
            lblFullName = new System.Windows.Forms.Label();
            openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            SuspendLayout();
            // 
            // sumatraPDFControl1
            // 
            sumatraPDFControl1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            sumatraPDFControl1.BackgroundImage = (System.Drawing.Image)resources.GetObject("sumatraPDFControl1.BackgroundImage");
            sumatraPDFControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            sumatraPDFControl1.DisplayMode = SumatraPDF.SumatraPDFControl.DisplayModeEnum.Automatic;
            sumatraPDFControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            sumatraPDFControl1.KeyAccelerators = false;
            sumatraPDFControl1.Location = new System.Drawing.Point(0, 0);
            sumatraPDFControl1.Margin = new System.Windows.Forms.Padding(0);
            sumatraPDFControl1.Name = "sumatraPDFControl1";
            sumatraPDFControl1.NamedDest = null;
            sumatraPDFControl1.Page = 0;
            sumatraPDFControl1.Size = new System.Drawing.Size(924, 503);
            sumatraPDFControl1.SumatraPDFExe = "SumatraPDF.exe";
            sumatraPDFControl1.SumatraPDFPath = null;
            sumatraPDFControl1.TabIndex = 0;
            sumatraPDFControl1.Text = "sumatraPDFControl1";
            sumatraPDFControl1.TocVisible = false;
            sumatraPDFControl1.ToolBarVisible = false;
            sumatraPDFControl1.Zoom = 0F;
            sumatraPDFControl1.ZoomVirtual = SumatraPDF.SumatraPDFControl.ZoomVirtualEnum.None;
            sumatraPDFControl1.Click += sumatraPDFControl1_Click;
            // 
            // lblFullName
            // 
            lblFullName.AutoSize = true;
            lblFullName.Dock = System.Windows.Forms.DockStyle.Bottom;
            lblFullName.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 134);
            lblFullName.Location = new System.Drawing.Point(0, 482);
            lblFullName.Name = "lblFullName";
            lblFullName.Padding = new System.Windows.Forms.Padding(1, 0, 1, 1);
            lblFullName.Size = new System.Drawing.Size(98, 21);
            lblFullName.TabIndex = 1;
            lblFullName.Text = "FileFullName";
            lblFullName.DoubleClick += lblFullName_DoubleClick;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(924, 503);
            Controls.Add(lblFullName);
            Controls.Add(sumatraPDFControl1);
            ForeColor = System.Drawing.SystemColors.ActiveCaption;
            Margin = new System.Windows.Forms.Padding(4);
            Name = "Form1";
            Text = "JustPDFViewer";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private SumatraPDF.SumatraPDFControl sumatraPDFControl1;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        
    }
}

