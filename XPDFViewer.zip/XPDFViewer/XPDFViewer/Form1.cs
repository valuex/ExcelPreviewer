﻿using SumatraPDF;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using System.IO;
using System.Diagnostics;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace XPDFViewer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //var PdfInstance=new SumatraPDFControl();
            //PdfInstance.OpenFile()
        }
        const int WM_COPYDATA = 0x004A;
        public struct COPYDATASTRUCT
        {
            public IntPtr dwData;
            public int cData;
            [MarshalAs(UnmanagedType.LPStr)]
            public string lpData;
        }
        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);

            switch (m.Msg)
            {
                case WM_COPYDATA:
                    COPYDATASTRUCT cdata = new COPYDATASTRUCT();
                    Type mytype = cdata.GetType();
                    cdata = (COPYDATASTRUCT)m.GetLParam(mytype);
                    var message = cdata.lpData;
                    //MessageBox.Show(message);
                    if (File.Exists(message))
                    {
                        string ext = Path.GetExtension(message);
                        if (ext == ".pdf")
                        {
                            sumatraPDFControl1.LoadFile(message);
                            lblFullName.Text = message;
                        }
                        else
                            MessageBox.Show("Not a pdf file: " + message);
                    }
                    else
                        MessageBox.Show("No such a file: " + message);
                    break;
                default:
                    base.DefWndProc(ref m);
                    break;
            }
        }

        private void sumatraPDFControl1_Click(object sender, EventArgs e)
        {           
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"D:\",
                Title = "Open",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = "pdf",
                Filter = "pdf file (*.pdf)|*.pdf",
                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string FilePath = openFileDialog1.FileName;
                sumatraPDFControl1.LoadFile(FilePath);
                lblFullName.Text = FilePath;
            }
        }

        private void lblFullName_DoubleClick(object sender, EventArgs e)
        {
            Process p = new Process();
            ProcessStartInfo pi = new ProcessStartInfo();
            pi.UseShellExecute = true;
            pi.FileName = @lblFullName.Text;
            p.StartInfo = pi;

            try
            {
                p.Start();
            }
            catch (Exception Ex)
            {
                //MessageBox.Show(Ex.Message);
            }
        }
    }
}
